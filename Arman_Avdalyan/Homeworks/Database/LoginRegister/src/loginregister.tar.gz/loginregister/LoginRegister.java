package loginregister;

public class LoginRegister {

    public static void main(String[] args) {
        new MainPage().setVisible(true);
    }
}

package loginregister;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SQLManager extends DatabaseManager {

    private static Connection connection;
    private final String JDBC_PREFIX = "jdbc:postgresql://localhost:5432/postgres";
    private final static String USER_NAME = "postgres";
    private final static String PASSWORD = "postgres";

    public SQLManager() {
        openConnection();
    }

    @Override
    public void finalize() {
        closeConnection();
    }

    @Override
    protected void closeConnection() {
        try {
            connection.close();
            System.out.println("[SQLManager] Connection is closed.");
        } catch (SQLException e) {
            System.out.println("[SQLManager] Connection close failed.");
        }
    }

    @Override
    protected void openConnection() {
        Properties props = new Properties();
        props.setProperty("user", USER_NAME);
        props.setProperty("password", PASSWORD);
        props.setProperty("ssl", "true");
        try {
            connection = DriverManager.getConnection(JDBC_PREFIX, props);
            System.out.println("[SQLManager] Connection is created.");
        } catch (SQLException ex) {
            Logger.getLogger(SQLManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public boolean createUser(String name, String userName, String password) {
        try {
            String sql = "INSERT INTO users(name, username, password) VALUES(?,?,?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, userName);
            pstmt.setString(3, password);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SQLManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean checkUser(String userName, String password) {
        try {
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, userName);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SQLManager.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}

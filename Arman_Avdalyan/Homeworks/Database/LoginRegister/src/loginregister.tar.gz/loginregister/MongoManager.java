package loginregister;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoManager extends DatabaseManager {

    private String url = "jdbc:mongodb://localhost:27017/users;User=mongo;Password=mongo;";
    private static MongoCollection collection;

    MongoManager() {
        openConnection();
    }

    @Override
    public void openConnection() {
//        MongoClient mongoClient = new MongoClient(new MongoClientURI(url));
        MongoClient mongoClient = new MongoClient();
        MongoDatabase database = mongoClient.getDatabase("users");
        collection = database.getCollection("user");
    }

    @Override
    public boolean createUser(String name, String userName, String password) {
        BasicDBObject doc = new BasicDBObject("name", name)
                .append("username", userName)
                .append("password", password);
        collection.insertOne(doc);
        return true;
    }

    @Override
    public boolean checkUser(String userName, String password) {
//        DBObject queryUsername = new BasicDBObject("username", userName);
//        DBObject queryPassword = new BasicDBObject("password", password);
//        DBCursor usernameCursor = (DBCursor) collection.find((Bson) queryUsername);
//        DBCursor passwordCursor = (DBCursor) collection.find((Bson) queryUsername);
//        return usernameCursor != null && passwordCursor != null;
        return false;
    }

    @Override
    public void closeConnection() {
    }
}
